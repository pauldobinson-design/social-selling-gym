"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type User = { id: string; name: string; avatarUrl?: string; xp: number };

type SSI = {
  brand: number;
  people: number;
  insights: number;
  relationships: number;
};

type Ctx = {
  user: User | null;
  signInMock: () => void;
  signOut: () => void;
  ssi: SSI;
  setSSI: (s: SSI) => void;
};

const C = createContext<Ctx | null>(null);

export function MockAuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ssi, setSSI] = useState<SSI>({ brand: 0, people: 0, insights: 0, relationships: 0 });
  const router = useRouter();

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem("ssg_user");
      const storedSSI = localStorage.getItem("ssg_ssi");
      if (storedUser) setUser(JSON.parse(storedUser));
      if (storedSSI) setSSI(JSON.parse(storedSSI));
    } catch {}
  }, []);

  function signInMock() {
    const u = { id: "u1", name: "Dobbo", avatarUrl: "", xp: 850 };
    setUser(u);
    localStorage.setItem("ssg_user", JSON.stringify(u));
    router.refresh();
  }
  function signOut() {
    setUser(null);
    localStorage.removeItem("ssg_user");
    router.refresh();
  }
  function setSSISafe(s: SSI) {
    setSSI(s);
    try { localStorage.setItem("ssg_ssi", JSON.stringify(s)); } catch {}
  }

  return <C.Provider value={{ user, signInMock, signOut, ssi, setSSI: setSSISafe }}>{children}</C.Provider>;
}

export function useMockAuth() {
  const ctx = useContext(C);
  if (!ctx) throw new Error("useMockAuth must be used within MockAuthProvider");
  return ctx;
}
