import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json();
  const text: string = String(body.text || "");
  const len = text.split(/\s+/).filter(Boolean).length;
  const inRange = len >= 220 && len <= 280;
  const json = {
    length: len,
    inIdealRange: inRange,
    tips: [
      !inRange ? "Aim for 220 to 280 words for scannability." : "Length looks good.",
      "Lead with a hook that names the tension or risk.",
      "Finish with a single CTA that is easy to act on."
    ]
  };
  return NextResponse.json(json);
}
