import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json();
  const vars = body.vars || {};
  const filled = {
    Name: vars.Name || "Dobbo",
    Outcome: vars.Outcome || "book a 30 minute discovery call",
    Proof: vars.Proof || "reduced onboarding time by 32% across 3 clients",
    Industry: vars.Industry || "Financial Services",
    Role: vars.Role || "CIO"
  };
  return NextResponse.json({ vars: filled });
}
