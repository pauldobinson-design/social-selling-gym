import { LEADERBOARD } from "@/data/leaderboard";

export default function Leaderboard() {
  const dedup = Object.values(LEADERBOARD.reduce((acc: any, cur) => {
    acc[cur.id] = acc[cur.id] && acc[cur.id].xp > cur.xp ? acc[cur.id] : cur;
    return acc;
  }, {} as Record<string, any>)).sort((a: any, b: any) => b.xp - a.xp);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Leaderboard</h1>
      <div className="card p-4">
        <div className="text-sm text-ink-700 mb-3">Tabs coming soon: Global, Industry, Friends, This week</div>
        <ul className="divide-y">
          {dedup.map((u: any, i: number) => (
            <li key={u.id} className="py-3 flex items-center gap-3">
              <span className="w-8 text-ink-700">{i + 1}</span>
              <span className="font-medium">{u.name}</span>
              <span className="ml-auto rounded-full bg-ink-100 px-3 py-1 text-xs">XP {u.xp}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
