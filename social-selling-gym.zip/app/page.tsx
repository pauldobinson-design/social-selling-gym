import Link from "next/link";

export default function Home() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Social Selling Gym</h1>
      <p className="text-ink-700 max-w-2xl">
        Practise social selling with guided challenges, AI coaching, and progress tracking. Sign in with Google soon,
        or use the mock login toggle in the footer while we finish auth.
      </p>
      <div className="flex gap-3">
        <Link href="/dashboard" className="btn btn-primary">Go to Dashboard</Link>
        <Link href="/challenges" className="btn">Browse Challenges</Link>
      </div>
    </div>
  );
}
