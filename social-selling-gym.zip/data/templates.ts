export const TEMPLATES = [
  {
    id: "t1",
    name: "Warm Intro DM",
    body: "Hi [Name], enjoyed your post on [Industry] trends. We helped a peer [Outcome] with [Proof]. If helpful, happy to share how they approached it. Worth a chat next week?"
  },
  {
    id: "t2",
    name: "Meeting Follow‑up",
    body: "Thanks for the time today [Name]. You mentioned [Role] priorities around [Industry]. Attaching a short note on options to [Outcome], including how a client [Proof]. Shall we lock a 30 minute working session?"
  }
];
