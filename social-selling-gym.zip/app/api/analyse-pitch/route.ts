import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json();
  const pitch: string = String(body.pitch || "").slice(0, 5000);
  // Simple fake scoring to keep the app working offline; swap with OpenAI later.
  const words = pitch.split(/\s+/).filter(Boolean).length;
  const score = Math.min(100, Math.max(40, 80 + Math.floor((200 - Math.abs(200 - words)) / 20)));
  const json = {
    score,
    subscores: {
      clarity: Math.min(100, score - 2),
      audienceFit: Math.min(100, score - 3),
      outcomeStrength: Math.min(100, score - 1),
      proof: Math.min(100, score - 5),
      brevity: Math.min(100, score - 4),
      voice: Math.min(100, score - 3)
    },
    edits: [
      "Tighten the hook to one sentence that names the problem and the outcome.",
      "Swap vague claims for one number that proves impact.",
      "End with a clear CTA that fits your audience and channel."
    ],
    tighterVersion: pitch.slice(0, 120).trim() + (pitch.length > 150 ? "..." : "")
  };
  return NextResponse.json(json);
}
