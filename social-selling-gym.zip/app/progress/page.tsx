"use client";

import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid } from "recharts";
import { useMemo } from "react";

const weekly = [
  { week: "W1", xp: 220 },
  { week: "W2", xp: 310 },
  { week: "W3", xp: 180 },
  { week: "W4", xp: 340 }
];

const categories = [
  { name: "LinkedIn", xp: 640 },
  { name: "Email", xp: 420 },
  { name: "Calls", xp: 220 }
];

export default function Progress() {
  const streak = useMemo(() => {
    return Array.from({ length: 30 }).map((_, i) => ({ day: i + 1, done: Math.random() > 0.4 }));
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Progress</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-4">
          <h2 className="font-semibold mb-2">Weekly XP</h2>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weekly}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="xp" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card p-4">
          <h2 className="font-semibold mb-2">Category breakdown</h2>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categories}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="xp" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="card p-4">
        <h2 className="font-semibold mb-3">Streak</h2>
        <div className="grid grid-cols-15 gap-1" style={{ gridTemplateColumns: "repeat(15, minmax(0, 1fr))" }}>
          {streak.map(s => (
            <div key={s.day} className={"h-6 rounded " + (s.done ? "bg-success" : "bg-ink-100")} title={"Day " + s.day} />
          ))}
        </div>
        <div className="mt-3 text-sm text-ink-700">Next best action: pick a LinkedIn challenge to extend your streak.</div>
      </div>
    </div>
  );
}
