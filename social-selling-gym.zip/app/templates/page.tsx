"use client";

import { useState } from "react";
import { TEMPLATES } from "@/data/templates";

export default function Templates() {
  const [vars, setVars] = useState<any>({ Name: "", Outcome: "", Proof: "", Industry: "", Role: "" });
  const [personalised, setPersonalised] = useState<any>(null);

  async function personalise(v: any) {
    const res = await fetch("/api/personalise-template", { method: "POST", body: JSON.stringify({ vars: v }) });
    const json = await res.json();
    setPersonalised(json.vars);
  }

  function fill(body: string) {
    const map = personalised || vars;
    return body
      .replaceAll("[Name]", map.Name || "[Name]")
      .replaceAll("[Outcome]", map.Outcome || "[Outcome]")
      .replaceAll("[Proof]", map.Proof || "[Proof]")
      .replaceAll("[Industry]", map.Industry || "[Industry]")
      .replaceAll("[Role]", map.Role || "[Role]");
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Templates</h1>

      <div className="card p-4 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-3">
          {["Name","Outcome","Proof","Industry","Role"].map(k => (
            <div key={k}>
              <label className="label">{k}</label>
              <input className="input" value={vars[k] || ""} onChange={(e) => setVars({ ...vars, [k]: e.target.value })} />
            </div>
          ))}
          <button className="btn" onClick={() => personalise(vars)}>Personalise with AI</button>
        </div>

        <div className="space-y-3">
          {TEMPLATES.map(t => (
            <div key={t.id} className="card p-4">
              <div className="font-semibold">{t.name}</div>
              <p className="text-sm text-ink-700 mt-2 whitespace-pre-wrap">{fill(t.body)}</p>
              <button
                className="btn mt-3"
                onClick={() => navigator.clipboard.writeText(fill(t.body))}
              >Copy</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
