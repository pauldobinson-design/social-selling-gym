import { NextResponse } from "next/server";

export async function POST() {
  // This route just flips a local flag by instructing the client to call signInMock.
  // Since we cannot mutate client state from server, we redirect to /dashboard with a query hint.
  return NextResponse.redirect(new URL("/dashboard?mock=1", process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"));
}
