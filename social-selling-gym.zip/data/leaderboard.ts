export const LEADERBOARD = [
  { id: "u1", name: "Dobbo", xp: 1250 },
  { id: "u2", name: "Alex", xp: 1190 },
  { id: "u3", name: "Sam", xp: 980 },
  { id: "u4", name: "Priya", xp: 940 }
];
