"use client";

import { useState } from "react";
import { useMockAuth } from "@/lib/mock-auth";

export function SSIModal() {
  const [open, setOpen] = useState(false);
  const { ssi, setSSI } = useMockAuth();
  const [form, setForm] = useState({
    brand: ssi.brand ?? 0,
    people: ssi.people ?? 0,
    insights: ssi.insights ?? 0,
    relationships: ssi.relationships ?? 0,
  });

  function onSave() {
    const toNum = (n: any) => Math.max(0, Math.min(25, Number(n) || 0));
    const data = {
      brand: toNum(form.brand),
      people: toNum(form.people),
      insights: toNum(form.insights),
      relationships: toNum(form.relationships)
    };
    setSSI(data);
    setOpen(false);
  }

  return (
    <div>
      <button className="btn btn-primary" onClick={() => setOpen(true)}>Add SSI scores</button>
      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/20 p-4">
          <div className="card w-full max-w-lg p-6 space-y-4">
            <h2 className="text-xl font-semibold">LinkedIn SSI</h2>
            <p className="text-sm text-ink-700">Enter scores from 0 to 25 for each pillar.</p>

            {([
              ["brand", "Establish Professional Brand"],
              ["people", "Find the Right People"],
              ["insights", "Engage with Insights"],
              ["relationships", "Build Relationships"]
            ] as const).map(([key, label]) => (
              <div key={key}>
                <label className="label">{label}</label>
                <input
                  className="input"
                  type="number"
                  min={0}
                  max={25}
                  value={form[key]}
                  onChange={(e) => setForm(prev => ({ ...prev, [key]: e.target.value }))}
                />
              </div>
            ))}

            <div className="flex justify-end gap-3 pt-2">
              <button className="btn" onClick={() => setOpen(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={onSave}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
